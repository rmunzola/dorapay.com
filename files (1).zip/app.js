/* ═══════════════════════════════════════════════════════════
   MMSG – Mobile Marketing Solutions Group
   app.js — Logique complète de l'application
   ═══════════════════════════════════════════════════════════ */

'use strict';

// ══════════════════════════════════════════
// ÉTAT GLOBAL (LocalStorage)
// ══════════════════════════════════════════
const DB = {
  load(key) {
    try { return JSON.parse(localStorage.getItem('mmsg_' + key)) || []; } catch { return []; }
  },
  save(key, data) {
    localStorage.setItem('mmsg_' + key, JSON.stringify(data));
  },
  loadObj(key, def = {}) {
    try { return JSON.parse(localStorage.getItem('mmsg_' + key)) || def; } catch { return def; }
  },
  saveObj(key, data) {
    localStorage.setItem('mmsg_' + key, JSON.stringify(data));
  }
};

// ══════════════════════════════════════════
// UTILISATEURS PAR DÉFAUT (Admin)
// ══════════════════════════════════════════
function initUsers() {
  let users = DB.load('users');
  if (!users.length) {
    users = [{
      id: 1, nom: 'Administrateur', login: 'admin', mdp: 'admin2025',
      role: 'admin', ville: 'Kinshasa', statut: 'actif'
    }];
    DB.save('users', users);
  }
  return users;
}

// ══════════════════════════════════════════
// CONFIGURATION
// ══════════════════════════════════════════
let CONFIG = DB.loadObj('config', {
  nom: 'Mobile Marketing Solutions Group',
  devise: '$', adresse: '', tel: '', email: '', tva: 16
});

// ══════════════════════════════════════════
// SESSION UTILISATEUR
// ══════════════════════════════════════════
let currentUser = null;

function doLogin() {
  const login = document.getElementById('loginUser').value.trim();
  const mdp = document.getElementById('loginPass').value;
  const users = initUsers();
  const user = users.find(u => u.login === login && u.mdp === mdp && u.statut === 'actif');
  if (!user) {
    document.getElementById('loginError').classList.remove('hidden');
    return;
  }
  currentUser = user;
  document.getElementById('loginError').classList.add('hidden');
  document.getElementById('loginPage').classList.remove('active');
  document.getElementById('loginPage').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  document.getElementById('app').classList.add('active');
  applyUserSession();
  initApp();
}

function applyUserSession() {
  document.getElementById('userName').textContent = currentUser.nom;
  document.getElementById('userRole').textContent = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
  document.getElementById('userAvatar').textContent = currentUser.nom.charAt(0).toUpperCase();
  document.getElementById('topbarUser').textContent = currentUser.nom;
  // Masquer admin si pas admin
  if (currentUser.role !== 'admin') {
    document.getElementById('adminLink').style.display = 'none';
    document.getElementById('btnAddCommercial') && (document.getElementById('btnAddCommercial').style.display = 'none');
  }
}

function doLogout() {
  currentUser = null;
  document.getElementById('app').classList.add('hidden');
  document.getElementById('app').classList.remove('active');
  document.getElementById('loginPage').classList.add('active');
  document.getElementById('loginPage').classList.remove('hidden');
  document.getElementById('loginUser').value = '';
  document.getElementById('loginPass').value = '';
}

// ══════════════════════════════════════════
// INIT APP
// ══════════════════════════════════════════
function initApp() {
  updateDate();
  setInterval(updateDate, 60000);
  updateKPIs();
  renderAll();
  showModule('dashboard');
}

function updateDate() {
  const now = new Date();
  document.getElementById('topbarDate').textContent =
    now.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function renderAll() {
  renderClients();
  renderCommerciaux();
  renderTargets();
  renderDevis();
  renderFactures();
  renderMarchands();
  renderCommissions();
  renderProduits();
  renderDepenses();
  renderTreso();
  renderUsers();
  populateSelects();
}

// ══════════════════════════════════════════
// NAVIGATION
// ══════════════════════════════════════════
function showModule(name) {
  document.querySelectorAll('.module').forEach(m => m.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const mod = document.getElementById('mod-' + name);
  if (mod) mod.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => {
    if (n.getAttribute('onclick') && n.getAttribute('onclick').includes("'" + name + "'")) {
      n.classList.add('active');
    }
  });
  const labels = {
    dashboard: 'Tableau de bord', crm: 'CRM – Clients',
    commerciaux: 'Commerciaux', targets: 'Objectifs / Targets',
    devis: 'Gestion des Devis', factures: 'Gestion des Factures',
    marchands: 'Suivi Marchands Pdirect', commissions: 'Commissions Pdirect',
    produits: 'Gestion des Produits', depenses: 'Dépenses',
    tresorerie: 'Trésorerie', admin: 'Administration'
  };
  document.getElementById('breadcrumb').textContent = labels[name] || name;
  if (name === 'dashboard') updateDashboard();
  if (name === 'depenses') updateDepenseKPIs();
  if (name === 'tresorerie') updateTresoKPIs();
}

function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const mc = document.getElementById('mainContent');
  if (window.innerWidth <= 768) {
    sb.classList.toggle('mobile-open');
  } else {
    sb.classList.toggle('collapsed');
    mc.classList.toggle('expanded');
  }
}

// ══════════════════════════════════════════
// MODALS
// ══════════════════════════════════════════
function openModal(id, resetForm = true) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.add('open');
  if (resetForm) {
    modal.querySelectorAll('input:not([readonly]), select, textarea').forEach(el => {
      if (el.type === 'hidden') return;
      el.value = '';
    });
    modal.querySelectorAll('input[type=hidden]').forEach(el => el.value = '');
    // Reset lines
    if (id === 'modalDevis') resetLines('devis');
    if (id === 'modalFacture') resetLines('facture');
  }
  populateSelects();
  if (id === 'modalFacture') {
    document.getElementById('factureTvaRate').textContent = CONFIG.tva;
    document.getElementById('factureNum').value = genNum('FA');
  }
  if (id === 'modalDevis') {
    document.getElementById('devisTvaRate').textContent = CONFIG.tva;
    document.getElementById('devisNum').value = genNum('DV');
  }
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// ══════════════════════════════════════════
// GÉNÉRATEUR N° AUTO
// ══════════════════════════════════════════
function genNum(prefix) {
  const year = new Date().getFullYear();
  const rand = Math.floor(Math.random() * 900) + 100;
  return `${prefix}-${year}-${rand}`;
}

// ══════════════════════════════════════════
// SELECTS DYNAMIQUES
// ══════════════════════════════════════════
function populateSelects() {
  const commerciaux = DB.load('commerciaux');
  const clients = DB.load('clients');
  const marchands = DB.load('marchands');

  const commSelects = ['clientCommercial', 'targetCommercial', 'marchandCommercial', 'commissionCommercial'];
  commSelects.forEach(sid => {
    const sel = document.getElementById(sid);
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '<option value="">-- Sélectionner --</option>';
    commerciaux.forEach(c => {
      sel.innerHTML += `<option value="${c.nom}" ${cur === c.nom ? 'selected' : ''}>${c.nom}</option>`;
    });
  });

  const clientSelects = ['devisClient', 'factureClient'];
  clientSelects.forEach(sid => {
    const sel = document.getElementById(sid);
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '<option value="">-- Sélectionner client --</option>';
    clients.forEach(c => {
      sel.innerHTML += `<option value="${c.nom}" ${cur === c.nom ? 'selected' : ''}>${c.nom}</option>`;
    });
  });

  const marchandSel = document.getElementById('commissionMarchand');
  if (marchandSel) {
    const cur = marchandSel.value;
    marchandSel.innerHTML = '<option value="">-- Sélectionner --</option>';
    marchands.forEach(m => {
      marchandSel.innerHTML += `<option value="${m.nom}" ${cur === m.nom ? 'selected' : ''}>${m.nom}</option>`;
    });
  }
}

// ══════════════════════════════════════════
// UTILITAIRES
// ══════════════════════════════════════════
function uid() { return Date.now() + Math.random().toString(36).slice(2, 7); }
function fmt(n) { return parseFloat(n || 0).toFixed(2) + ' ' + CONFIG.devise; }
function toast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = (type === 'success' ? '✓ ' : '⚠ ') + msg;
  t.className = 'toast ' + type;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 3000);
}

function filterTable(tableId, searchId) {
  const q = document.getElementById(searchId).value.toLowerCase();
  const rows = document.querySelectorAll('#' + tableId + ' tbody tr');
  rows.forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function statusBadge(status) {
  const map = {
    'actif': 'badge-green', 'active': 'badge-green', 'actif': 'badge-green',
    'inactif': 'badge-grey', 'suspendu': 'badge-red', 'désinstallé': 'badge-red',
    'prospect': 'badge-blue', 'installé': 'badge-blue',
    'payée': 'badge-green', 'non payée': 'badge-red', 'partiel': 'badge-orange',
    'brouillon': 'badge-grey', 'envoyé': 'badge-blue', 'accepté': 'badge-green', 'refusé': 'badge-red',
    'en attente': 'badge-orange', 'admin': 'badge-red', 'commercial': 'badge-blue', 'comptable': 'badge-orange'
  };
  const cls = map[(status || '').toLowerCase()] || 'badge-grey';
  return `<span class="badge ${cls}">${status || '—'}</span>`;
}

// ══════════════════════════════════════════
// KPI DASHBOARD
// ══════════════════════════════════════════
function updateKPIs() {
  const clients = DB.load('clients');
  const factures = DB.load('factures');
  const marchands = DB.load('marchands');
  const commerciaux = DB.load('commerciaux');
  const depenses = DB.load('depenses');

  const now = new Date();
  const mois = now.getMonth(); const annee = now.getFullYear();

  const ca = factures.filter(f => f.statut === 'payée').reduce((s, f) => s + (parseFloat(f.total) || 0), 0);
  const depMois = depenses.filter(d => {
    const dd = new Date(d.date);
    return dd.getMonth() === mois && dd.getFullYear() === annee;
  }).reduce((s, d) => s + (parseFloat(d.montant) || 0), 0);

  document.getElementById('kpiClients').textContent = clients.length;
  document.getElementById('kpiFactures').textContent = factures.length;
  document.getElementById('kpiMarchands').textContent = marchands.length;
  document.getElementById('kpiCA').textContent = fmt(ca);
  document.getElementById('kpiCommerciaux').textContent = commerciaux.filter(c => c.statut === 'actif').length;
  document.getElementById('kpiDepenses').textContent = fmt(depMois);
}

function updateDashboard() {
  updateKPIs();
  renderRecentActivities();
  renderDashTargets();
}

function renderRecentActivities() {
  const container = document.getElementById('recentActivities');
  const all = [];
  ['clients', 'factures', 'devis', 'marchands'].forEach(key => {
    DB.load(key).slice(-3).forEach(item => {
      all.push({ type: key, label: item.nom || item.num || '—', date: item.created || item.date || '' });
    });
  });
  all.sort((a, b) => new Date(b.date) - new Date(a.date));
  if (!all.length) {
    container.innerHTML = '<div class="empty-state"><i class="fas fa-clock"></i><p>Aucune activité récente</p></div>';
    return;
  }
  const colors = { clients: 'blue', factures: 'green', devis: 'blue', marchands: 'red' };
  const labels = { clients: 'Nouveau client', factures: 'Facture émise', devis: 'Devis créé', marchands: 'Marchand ajouté' };
  container.innerHTML = all.slice(0, 6).map(a => `
    <div class="activity-item">
      <div class="activity-dot ${colors[a.type] || 'blue'}"></div>
      <div>
        <div class="activity-text"><strong>${labels[a.type] || a.type}</strong>: ${a.label}</div>
        <div class="activity-time">${a.date ? new Date(a.date).toLocaleDateString('fr-FR') : 'Date inconnue'}</div>
      </div>
    </div>`).join('');
}

function renderDashTargets() {
  const targets = DB.load('targets');
  const container = document.getElementById('dashTargets');
  if (!targets.length) {
    container.innerHTML = '<div class="empty-state"><i class="fas fa-bullseye"></i><p>Aucun objectif défini</p></div>';
    return;
  }
  container.innerHTML = targets.slice(0, 5).map(t => {
    const pct = t.objectif > 0 ? Math.min(100, Math.round((t.realise / t.objectif) * 100)) : 0;
    const barColor = pct >= 100 ? 'green' : pct >= 50 ? 'blue' : 'red';
    return `
      <div class="target-item">
        <div class="target-meta">
          <span class="target-name">${t.commercial} — ${t.type}</span>
          <span class="target-pct" style="color:var(--${barColor === 'green' ? 'blue' : barColor})">${pct}%</span>
        </div>
        <div class="progress-bar-wrap">
          <div class="progress-bar ${barColor}" style="width:${pct}%"></div>
        </div>
        <div style="font-size:.72rem;color:var(--text-muted);margin-top:.3rem">
          Réalisé: ${t.realise} / Objectif: ${t.objectif} — ${t.periode}
        </div>
      </div>`;
  }).join('');
}

// ══════════════════════════════════════════
// CLIENTS CRM
// ══════════════════════════════════════════
function saveClient() {
  const id = document.getElementById('clientId').value;
  const data = {
    id: id || uid(),
    nom: document.getElementById('clientNom').value.trim(),
    email: document.getElementById('clientEmail').value.trim(),
    tel: document.getElementById('clientTel').value.trim(),
    ville: document.getElementById('clientVille').value.trim(),
    statut: document.getElementById('clientStatut').value,
    commercial: document.getElementById('clientCommercial').value,
    notes: document.getElementById('clientNotes').value.trim(),
    created: new Date().toISOString()
  };
  if (!data.nom) { toast('Le nom est obligatoire', 'error'); return; }
  let list = DB.load('clients');
  if (id) list = list.map(c => c.id === id ? data : c);
  else list.push(data);
  DB.save('clients', list);
  closeModal('modalClient');
  renderClients();
  updateKPIs();
  toast('Client enregistré avec succès');
}

function renderClients() {
  let list = DB.load('clients');
  const filter = document.getElementById('filterClientStatut')?.value || '';
  if (filter) list = list.filter(c => c.statut === filter);
  const tbody = document.getElementById('bodyClients');
  tbody.innerHTML = list.length ? list.map((c, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${c.nom}</strong></td>
      <td>${c.email || '—'}</td>
      <td>${c.tel || '—'}</td>
      <td>${c.ville || '—'}</td>
      <td>${statusBadge(c.statut)}</td>
      <td>${c.commercial || '—'}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editClient('${c.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('clients','${c.id}',renderClients)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun client</td></tr>';
}

function editClient(id) {
  const c = DB.load('clients').find(x => x.id === id);
  if (!c) return;
  openModal('modalClient', false);
  document.getElementById('clientId').value = c.id;
  document.getElementById('clientNom').value = c.nom;
  document.getElementById('clientEmail').value = c.email;
  document.getElementById('clientTel').value = c.tel;
  document.getElementById('clientVille').value = c.ville;
  document.getElementById('clientStatut').value = c.statut;
  document.getElementById('clientCommercial').value = c.commercial;
  document.getElementById('clientNotes').value = c.notes;
}

// ══════════════════════════════════════════
// COMMERCIAUX
// ══════════════════════════════════════════
function saveCommercial() {
  const id = document.getElementById('commId').value;
  const data = {
    id: id || uid(),
    nom: document.getElementById('commNom').value.trim(),
    login: document.getElementById('commLogin').value.trim(),
    mdp: document.getElementById('commMdp').value,
    email: document.getElementById('commEmail').value.trim(),
    tel: document.getElementById('commTel').value.trim(),
    ville: document.getElementById('commVille').value.trim(),
    zone: document.getElementById('commZone').value.trim(),
    statut: document.getElementById('commStatut').value,
    role: 'commercial'
  };
  if (!data.nom || !data.login) { toast('Nom et login obligatoires', 'error'); return; }
  // Vérifier login unique
  const list = DB.load('commerciaux');
  if (!id && list.find(c => c.login === data.login)) { toast('Ce login existe déjà', 'error'); return; }

  let updated = id ? list.map(c => c.id === id ? { ...c, ...data } : c) : [...list, data];
  DB.save('commerciaux', updated);

  // Ajouter dans users pour connexion
  let users = DB.load('users');
  if (!id) {
    if (!users.find(u => u.login === data.login)) {
      users.push({ id: uid(), nom: data.nom, login: data.login, mdp: data.mdp, role: 'commercial', ville: data.ville, statut: 'actif' });
      DB.save('users', users);
    }
  }
  closeModal('modalCommercial');
  renderCommerciaux();
  renderUsers();
  updateKPIs();
  populateSelects();
  toast('Commercial enregistré avec succès');
}

function renderCommerciaux() {
  const list = DB.load('commerciaux');
  const tbody = document.getElementById('bodyCommerciaux');
  tbody.innerHTML = list.length ? list.map((c, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${c.nom}</strong></td>
      <td><code>${c.login}</code></td>
      <td>${c.email || '—'}</td>
      <td>${c.tel || '—'}</td>
      <td>${c.ville || '—'}</td>
      <td>${c.zone || '—'}</td>
      <td>${statusBadge(c.statut)}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editCommercial('${c.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('commerciaux','${c.id}',renderCommerciaux)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun commercial</td></tr>';
}

function editCommercial(id) {
  const c = DB.load('commerciaux').find(x => x.id === id);
  if (!c) return;
  openModal('modalCommercial', false);
  document.getElementById('commId').value = c.id;
  document.getElementById('commNom').value = c.nom;
  document.getElementById('commLogin').value = c.login;
  document.getElementById('commMdp').value = c.mdp || '';
  document.getElementById('commEmail').value = c.email;
  document.getElementById('commTel').value = c.tel;
  document.getElementById('commVille').value = c.ville;
  document.getElementById('commZone').value = c.zone;
  document.getElementById('commStatut').value = c.statut;
}

// ══════════════════════════════════════════
// TARGETS
// ══════════════════════════════════════════
function saveTarget() {
  const id = document.getElementById('targetId').value;
  const data = {
    id: id || uid(),
    commercial: document.getElementById('targetCommercial').value,
    periode: document.getElementById('targetPeriode').value,
    type: document.getElementById('targetType').value,
    objectif: parseFloat(document.getElementById('targetVal').value) || 0,
    realise: parseFloat(document.getElementById('targetRealise').value) || 0
  };
  if (!data.commercial || !data.periode) { toast('Commercial et période obligatoires', 'error'); return; }
  let list = DB.load('targets');
  if (id) list = list.map(t => t.id === id ? data : t);
  else list.push(data);
  DB.save('targets', list);
  closeModal('modalTarget');
  renderTargets();
  toast('Objectif enregistré');
}

function renderTargets() {
  const list = DB.load('targets');
  const tbody = document.getElementById('bodyTargets');
  tbody.innerHTML = list.length ? list.map((t, i) => {
    const pct = t.objectif > 0 ? Math.min(100, Math.round((t.realise / t.objectif) * 100)) : 0;
    const s = pct >= 100 ? 'Atteint' : pct >= 50 ? 'En cours' : 'En retard';
    return `
    <tr>
      <td>${i + 1}</td>
      <td>${t.commercial}</td>
      <td>${t.periode}</td>
      <td>${t.type}</td>
      <td>${t.objectif}</td>
      <td>${t.realise}</td>
      <td><strong>${pct}%</strong></td>
      <td>${statusBadge(s)}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editTarget('${t.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('targets','${t.id}',renderTargets)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`;
  }).join('') : '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun objectif</td></tr>';
}

function editTarget(id) {
  const t = DB.load('targets').find(x => x.id === id);
  if (!t) return;
  openModal('modalTarget', false);
  document.getElementById('targetId').value = t.id;
  document.getElementById('targetCommercial').value = t.commercial;
  document.getElementById('targetPeriode').value = t.periode;
  document.getElementById('targetType').value = t.type;
  document.getElementById('targetVal').value = t.objectif;
  document.getElementById('targetRealise').value = t.realise;
}

// ══════════════════════════════════════════
// LIGNES FACTURE / DEVIS
// ══════════════════════════════════════════
let lineCounters = { devis: 0, facture: 0 };

function resetLines(ctx) {
  lineCounters[ctx] = 0;
  const container = document.getElementById(ctx + 'Lines');
  const header = container.querySelector('.line-header');
  container.innerHTML = '';
  container.appendChild(header);
  updateTotaux(ctx);
}

function addLine(ctx) {
  lineCounters[ctx]++;
  const id = ctx + '_line_' + lineCounters[ctx];
  const container = document.getElementById(ctx + 'Lines');
  const div = document.createElement('div');
  div.className = 'invoice-line';
  div.id = id;
  div.innerHTML = `
    <input type="text" placeholder="Désignation" oninput="calcLine('${id}','${ctx}')"/>
    <input type="number" placeholder="1" min="0" step="any" value="1" oninput="calcLine('${id}','${ctx}')"/>
    <input type="number" placeholder="0.00" min="0" step="0.01" value="0" oninput="calcLine('${id}','${ctx}')"/>
    <span class="line-total">0.00 ${CONFIG.devise}</span>
    <button class="btn-remove" onclick="removeLine('${id}','${ctx}')"><i class="fas fa-times"></i></button>
  `;
  container.appendChild(div);
}

function calcLine(lineId, ctx) {
  const line = document.getElementById(lineId);
  if (!line) return;
  const inputs = line.querySelectorAll('input[type=number]');
  const qty = parseFloat(inputs[0].value) || 0;
  const pu = parseFloat(inputs[1].value) || 0;
  const total = qty * pu;
  line.querySelector('.line-total').textContent = total.toFixed(2) + ' ' + CONFIG.devise;
  updateTotaux(ctx);
}

function removeLine(lineId, ctx) {
  const el = document.getElementById(lineId);
  if (el) el.remove();
  updateTotaux(ctx);
}

function updateTotaux(ctx) {
  const container = document.getElementById(ctx + 'Lines');
  let ht = 0;
  container.querySelectorAll('.invoice-line').forEach(line => {
    const inputs = line.querySelectorAll('input[type=number]');
    ht += (parseFloat(inputs[0]?.value) || 0) * (parseFloat(inputs[1]?.value) || 0);
  });
  const tva = ht * (CONFIG.tva / 100);
  const ttc = ht + tva;
  document.getElementById(ctx + 'HT').textContent = ht.toFixed(2) + ' ' + CONFIG.devise;
  document.getElementById(ctx + 'TVA').textContent = tva.toFixed(2) + ' ' + CONFIG.devise;
  const ttcEl = document.getElementById(ctx === 'devis' ? 'dvisTTC' : 'factureTTC');
  if (ttcEl) ttcEl.textContent = ttc.toFixed(2) + ' ' + CONFIG.devise;
  return { ht, tva, ttc };
}

function getLinesData(ctx) {
  const container = document.getElementById(ctx + 'Lines');
  const lines = [];
  container.querySelectorAll('.invoice-line').forEach(line => {
    const inputs = line.querySelectorAll('input');
    const numInputs = line.querySelectorAll('input[type=number]');
    lines.push({
      designation: inputs[0]?.value || '',
      qty: parseFloat(numInputs[0]?.value) || 0,
      pu: parseFloat(numInputs[1]?.value) || 0,
      total: (parseFloat(numInputs[0]?.value) || 0) * (parseFloat(numInputs[1]?.value) || 0)
    });
  });
  return lines;
}

// ══════════════════════════════════════════
// DEVIS
// ══════════════════════════════════════════
function saveDevis() {
  const id = document.getElementById('devisId').value;
  const totaux = updateTotaux('devis');
  const lines = getLinesData('devis');
  const data = {
    id: id || uid(),
    num: document.getElementById('devisNum').value,
    client: document.getElementById('devisClient').value,
    date: document.getElementById('devisDate').value,
    validite: document.getElementById('devisValidite').value,
    statut: document.getElementById('devisStatut').value,
    ht: totaux.ht, tva: totaux.tva, total: totaux.ttc,
    lines, created: new Date().toISOString()
  };
  if (!data.client || !data.date) { toast('Client et date obligatoires', 'error'); return; }
  let list = DB.load('devis');
  if (id) list = list.map(d => d.id === id ? data : d);
  else list.push(data);
  DB.save('devis', list);
  closeModal('modalDevis');
  renderDevis();
  toast('Devis enregistré');
}

function renderDevis() {
  const list = DB.load('devis');
  const tbody = document.getElementById('bodyDevis');
  tbody.innerHTML = list.length ? list.map((d, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${d.num}</strong></td>
      <td>${d.client}</td>
      <td>${d.date ? new Date(d.date).toLocaleDateString('fr-FR') : '—'}</td>
      <td>${d.validite ? new Date(d.validite).toLocaleDateString('fr-FR') : '—'}</td>
      <td><strong>${fmt(d.total)}</strong></td>
      <td>${statusBadge(d.statut)}</td>
      <td>
        <button class="btn-icon btn-edit" title="Convertir en facture" onclick="devisToFacture('${d.id}')"><i class="fas fa-file-invoice"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('devis','${d.id}',renderDevis)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun devis</td></tr>';
}

function devisToFacture(id) {
  const d = DB.load('devis').find(x => x.id === id);
  if (!d) return;
  openModal('modalFacture');
  document.getElementById('factureClient').value = d.client;
  document.getElementById('factureDate').value = new Date().toISOString().split('T')[0];
  resetLines('facture');
  (d.lines || []).forEach(line => {
    addLine('facture');
    const container = document.getElementById('factureLines');
    const lastLine = container.querySelectorAll('.invoice-line');
    const last = lastLine[lastLine.length - 1];
    if (last) {
      const inputs = last.querySelectorAll('input');
      const numInputs = last.querySelectorAll('input[type=number]');
      if (inputs[0]) inputs[0].value = line.designation;
      if (numInputs[0]) numInputs[0].value = line.qty;
      if (numInputs[1]) numInputs[1].value = line.pu;
      updateTotaux('facture');
    }
  });
  toast('Devis converti en facture');
}

// ══════════════════════════════════════════
// FACTURES
// ══════════════════════════════════════════
function saveFacture() {
  const id = document.getElementById('factureId').value;
  const totaux = updateTotaux('facture');
  const lines = getLinesData('facture');
  const data = {
    id: id || uid(),
    num: document.getElementById('factureNum').value,
    client: document.getElementById('factureClient').value,
    date: document.getElementById('factureDate').value,
    echeance: document.getElementById('factureEcheance').value,
    statut: document.getElementById('factureStatut').value,
    ht: totaux.ht, tva: totaux.tva, total: totaux.ttc,
    lines, created: new Date().toISOString()
  };
  if (!data.client || !data.date) { toast('Client et date obligatoires', 'error'); return; }
  let list = DB.load('factures');
  if (id) list = list.map(f => f.id === id ? data : f);
  else list.push(data);
  DB.save('factures', list);
  closeModal('modalFacture');
  renderFactures();
  updateKPIs();
  toast('Facture enregistrée');
}

function renderFactures() {
  const list = DB.load('factures');
  const tbody = document.getElementById('bodyFactures');
  tbody.innerHTML = list.length ? list.map((f, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${f.num}</strong></td>
      <td>${f.client}</td>
      <td>${f.date ? new Date(f.date).toLocaleDateString('fr-FR') : '—'}</td>
      <td>${f.echeance ? new Date(f.echeance).toLocaleDateString('fr-FR') : '—'}</td>
      <td><strong>${fmt(f.total)}</strong></td>
      <td>${statusBadge(f.statut)}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="printFactureById('${f.id}')" title="Imprimer"><i class="fas fa-print"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('factures','${f.id}',renderFactures)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Aucune facture</td></tr>';
}

function printFactureById(id) {
  const f = DB.load('factures').find(x => x.id === id);
  if (!f) return;
  const zone = document.getElementById('printZone');
  zone.innerHTML = `
    <div class="print-header">
      <div>
        <div class="print-logo">MMSG</div>
        <div>${CONFIG.nom}</div>
        <div>${CONFIG.adresse || ''}</div>
        <div>${CONFIG.tel || ''} | ${CONFIG.email || ''}</div>
      </div>
      <div style="text-align:right">
        <h2 style="color:#D32F2F;font-family:Rajdhani,sans-serif;font-size:2rem">FACTURE</h2>
        <div><strong>N°:</strong> ${f.num}</div>
        <div><strong>Date:</strong> ${f.date ? new Date(f.date).toLocaleDateString('fr-FR') : '—'}</div>
        <div><strong>Échéance:</strong> ${f.echeance ? new Date(f.echeance).toLocaleDateString('fr-FR') : '—'}</div>
      </div>
    </div>
    <div><strong>Facturé à:</strong> ${f.client}</div>
    <table class="print-table">
      <thead><tr><th>Désignation</th><th>Qté</th><th>P.U.</th><th>Total</th></tr></thead>
      <tbody>
        ${(f.lines || []).map(l => `<tr><td>${l.designation}</td><td>${l.qty}</td><td>${l.pu.toFixed(2)} ${CONFIG.devise}</td><td>${l.total.toFixed(2)} ${CONFIG.devise}</td></tr>`).join('')}
      </tbody>
    </table>
    <div class="print-totaux">
      <div>Sous-total HT: <strong>${fmt(f.ht)}</strong></div>
      <div>TVA (${CONFIG.tva}%): <strong>${fmt(f.tva)}</strong></div>
      <div style="font-size:1.3rem;font-weight:700;color:#D32F2F">TOTAL TTC: ${fmt(f.total)}</div>
    </div>
    <div style="margin-top:2rem;border-top:1px solid #ddd;padding-top:1rem;font-size:.85rem;color:#666">
      Statut: ${f.statut} | Merci pour votre confiance — ${CONFIG.nom}
    </div>
  `;
  setTimeout(() => window.print(), 100);
}

function printFacture() { printFactureById(document.getElementById('factureId').value); }

// ══════════════════════════════════════════
// MARCHANDS
// ══════════════════════════════════════════
function saveMarchand() {
  const id = document.getElementById('marchandId').value;
  const data = {
    id: id || uid(),
    nom: document.getElementById('marchandNom').value.trim(),
    tel: document.getElementById('marchandTel').value.trim(),
    secteur: document.getElementById('marchandSecteur').value.trim(),
    ville: document.getElementById('marchandVille').value.trim(),
    commercial: document.getElementById('marchandCommercial').value,
    date: document.getElementById('marchandDate').value,
    statut: document.getElementById('marchandStatut').value,
    pdirectId: document.getElementById('marchandPdirectId').value.trim(),
    created: new Date().toISOString()
  };
  if (!data.nom) { toast('Nom marchand obligatoire', 'error'); return; }
  let list = DB.load('marchands');
  if (id) list = list.map(m => m.id === id ? data : m);
  else list.push(data);
  DB.save('marchands', list);
  closeModal('modalMarchand');
  renderMarchands();
  updateKPIs();
  populateSelects();
  toast('Marchand enregistré');
}

function renderMarchands() {
  const list = DB.load('marchands');
  const tbody = document.getElementById('bodyMarchands');
  tbody.innerHTML = list.length ? list.map((m, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${m.nom}</strong></td>
      <td>${m.tel || '—'}</td>
      <td>${m.secteur || '—'}</td>
      <td>${m.ville || '—'}</td>
      <td>${m.commercial || '—'}</td>
      <td>${m.date ? new Date(m.date).toLocaleDateString('fr-FR') : '—'}</td>
      <td>${statusBadge(m.statut)}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editMarchand('${m.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('marchands','${m.id}',renderMarchands)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun marchand</td></tr>';
}

function editMarchand(id) {
  const m = DB.load('marchands').find(x => x.id === id);
  if (!m) return;
  openModal('modalMarchand', false);
  document.getElementById('marchandId').value = m.id;
  document.getElementById('marchandNom').value = m.nom;
  document.getElementById('marchandTel').value = m.tel;
  document.getElementById('marchandSecteur').value = m.secteur;
  document.getElementById('marchandVille').value = m.ville;
  document.getElementById('marchandCommercial').value = m.commercial;
  document.getElementById('marchandDate').value = m.date;
  document.getElementById('marchandStatut').value = m.statut;
  document.getElementById('marchandPdirectId').value = m.pdirectId;
}

// ══════════════════════════════════════════
// COMMISSIONS
// ══════════════════════════════════════════
function calcCommission() {
  const vol = parseFloat(document.getElementById('commissionVolume').value) || 0;
  const taux = parseFloat(document.getElementById('commissionTaux').value) || 0;
  document.getElementById('commissionMontant').value = (vol * taux / 100).toFixed(2);
}

function saveCommission() {
  const id = document.getElementById('commissionId').value;
  const data = {
    id: id || uid(),
    marchand: document.getElementById('commissionMarchand').value,
    periode: document.getElementById('commissionPeriode').value,
    volume: parseFloat(document.getElementById('commissionVolume').value) || 0,
    taux: parseFloat(document.getElementById('commissionTaux').value) || 0,
    montant: parseFloat(document.getElementById('commissionMontant').value) || 0,
    commercial: document.getElementById('commissionCommercial').value,
    statut: document.getElementById('commissionStatut').value
  };
  if (!data.marchand || !data.periode) { toast('Marchand et période obligatoires', 'error'); return; }
  let list = DB.load('commissions');
  if (id) list = list.map(c => c.id === id ? data : c);
  else list.push(data);
  DB.save('commissions', list);
  closeModal('modalCommission');
  renderCommissions();
  toast('Commission enregistrée');
}

function renderCommissions() {
  const list = DB.load('commissions');
  const tbody = document.getElementById('bodyCommissions');
  tbody.innerHTML = list.length ? list.map((c, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${c.marchand}</strong></td>
      <td>${c.periode}</td>
      <td>${fmt(c.volume)}</td>
      <td>${c.taux}%</td>
      <td><strong>${fmt(c.montant)}</strong></td>
      <td>${c.commercial || '—'}</td>
      <td>${statusBadge(c.statut)}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editCommission('${c.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('commissions','${c.id}',renderCommissions)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:2rem">Aucune commission</td></tr>';
}

function editCommission(id) {
  const c = DB.load('commissions').find(x => x.id === id);
  if (!c) return;
  openModal('modalCommission', false);
  document.getElementById('commissionId').value = c.id;
  document.getElementById('commissionMarchand').value = c.marchand;
  document.getElementById('commissionPeriode').value = c.periode;
  document.getElementById('commissionVolume').value = c.volume;
  document.getElementById('commissionTaux').value = c.taux;
  document.getElementById('commissionMontant').value = c.montant;
  document.getElementById('commissionCommercial').value = c.commercial;
  document.getElementById('commissionStatut').value = c.statut;
}

// ══════════════════════════════════════════
// PRODUITS
// ══════════════════════════════════════════
function saveProduit() {
  const id = document.getElementById('produitId').value;
  const data = {
    id: id || uid(),
    ref: document.getElementById('produitRef').value.trim(),
    nom: document.getElementById('produitNom').value.trim(),
    categorie: document.getElementById('produitCat').value.trim(),
    prix: parseFloat(document.getElementById('produitPrix').value) || 0,
    stock: parseInt(document.getElementById('produitStock').value) || 0,
    unite: document.getElementById('produitUnite').value,
    description: document.getElementById('produitDesc').value.trim()
  };
  if (!data.nom) { toast('Nom produit obligatoire', 'error'); return; }
  let list = DB.load('produits');
  if (id) list = list.map(p => p.id === id ? data : p);
  else list.push(data);
  DB.save('produits', list);
  closeModal('modalProduit');
  renderProduits();
  toast('Produit enregistré');
}

function renderProduits() {
  const list = DB.load('produits');
  const tbody = document.getElementById('bodyProduits');
  tbody.innerHTML = list.length ? list.map((p, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><code>${p.ref || '—'}</code></td>
      <td><strong>${p.nom}</strong></td>
      <td>${p.categorie || '—'}</td>
      <td>${fmt(p.prix)}</td>
      <td>${p.stock}</td>
      <td>${p.unite}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editProduit('${p.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('produits','${p.id}',renderProduits)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun produit</td></tr>';
}

function editProduit(id) {
  const p = DB.load('produits').find(x => x.id === id);
  if (!p) return;
  openModal('modalProduit', false);
  document.getElementById('produitId').value = p.id;
  document.getElementById('produitRef').value = p.ref;
  document.getElementById('produitNom').value = p.nom;
  document.getElementById('produitCat').value = p.categorie;
  document.getElementById('produitPrix').value = p.prix;
  document.getElementById('produitStock').value = p.stock;
  document.getElementById('produitUnite').value = p.unite;
  document.getElementById('produitDesc').value = p.description;
}

// ══════════════════════════════════════════
// DÉPENSES
// ══════════════════════════════════════════
function saveDepense() {
  const id = document.getElementById('depenseId').value;
  const data = {
    id: id || uid(),
    date: document.getElementById('depenseDate').value,
    libelle: document.getElementById('depenseLibelle').value.trim(),
    categorie: document.getElementById('depenseCat').value,
    montant: parseFloat(document.getElementById('depenseMontant').value) || 0,
    payePar: document.getElementById('depensePayePar').value.trim(),
    justif: document.getElementById('depenseJustif').value.trim()
  };
  if (!data.libelle || !data.date) { toast('Libellé et date obligatoires', 'error'); return; }
  let list = DB.load('depenses');
  if (id) list = list.map(d => d.id === id ? data : d);
  else list.push(data);
  DB.save('depenses', list);
  closeModal('modalDepense');
  renderDepenses();
  updateDepenseKPIs();
  updateKPIs();
  toast('Dépense enregistrée');
}

function renderDepenses() {
  const list = DB.load('depenses').sort((a, b) => new Date(b.date) - new Date(a.date));
  const tbody = document.getElementById('bodyDepenses');
  tbody.innerHTML = list.length ? list.map((d, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${d.date ? new Date(d.date).toLocaleDateString('fr-FR') : '—'}</td>
      <td><strong>${d.libelle}</strong></td>
      <td><span class="badge badge-blue">${d.categorie}</span></td>
      <td><strong>${fmt(d.montant)}</strong></td>
      <td>${d.payePar || '—'}</td>
      <td>${d.justif || '—'}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editDepense('${d.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('depenses','${d.id}',renderDepenses)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Aucune dépense</td></tr>';
}

function editDepense(id) {
  const d = DB.load('depenses').find(x => x.id === id);
  if (!d) return;
  openModal('modalDepense', false);
  document.getElementById('depenseId').value = d.id;
  document.getElementById('depenseDate').value = d.date;
  document.getElementById('depenseLibelle').value = d.libelle;
  document.getElementById('depenseCat').value = d.categorie;
  document.getElementById('depenseMontant').value = d.montant;
  document.getElementById('depensePayePar').value = d.payePar;
  document.getElementById('depenseJustif').value = d.justif;
}

function updateDepenseKPIs() {
  const list = DB.load('depenses');
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const mois = now.getMonth(); const annee = now.getFullYear();
  const jour = list.filter(d => d.date === todayStr).reduce((s, d) => s + (d.montant || 0), 0);
  const m = list.filter(d => { const dd = new Date(d.date); return dd.getMonth() === mois && dd.getFullYear() === annee; }).reduce((s, d) => s + (d.montant || 0), 0);
  const a = list.filter(d => new Date(d.date).getFullYear() === annee).reduce((s, d) => s + (d.montant || 0), 0);
  document.getElementById('depJour').textContent = fmt(jour);
  document.getElementById('depMois').textContent = fmt(m);
  document.getElementById('depAnnee').textContent = fmt(a);
}

// ══════════════════════════════════════════
// TRÉSORERIE
// ══════════════════════════════════════════
function saveTreso() {
  const id = document.getElementById('tresoId').value;
  const data = {
    id: id || uid(),
    date: document.getElementById('tresoDate').value,
    libelle: document.getElementById('tresoLibelle').value.trim(),
    type: document.getElementById('tresoType').value,
    montant: parseFloat(document.getElementById('tresoMontant').value) || 0,
    compte: document.getElementById('tresoCompte').value,
    ref: document.getElementById('tresoRef').value.trim()
  };
  if (!data.libelle || !data.date) { toast('Libellé et date obligatoires', 'error'); return; }
  let list = DB.load('treso');
  if (id) list = list.map(t => t.id === id ? data : t);
  else list.push(data);
  DB.save('treso', list);
  closeModal('modalTreso');
  renderTreso();
  updateTresoKPIs();
  toast('Mouvement enregistré');
}

function renderTreso() {
  const list = DB.load('treso').sort((a, b) => new Date(b.date) - new Date(a.date));
  const tbody = document.getElementById('bodyTreso');
  tbody.innerHTML = list.length ? list.map((t, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${t.date ? new Date(t.date).toLocaleDateString('fr-FR') : '—'}</td>
      <td><strong>${t.libelle}</strong></td>
      <td>${t.type === 'entrée' ? '<span class="badge badge-green">↓ Entrée</span>' : '<span class="badge badge-red">↑ Sortie</span>'}</td>
      <td style="font-weight:700;color:${t.type === 'entrée' ? 'var(--blue)' : 'var(--red)'}">
        ${t.type === 'entrée' ? '+' : '-'}${fmt(t.montant)}
      </td>
      <td>${t.compte}</td>
      <td>${t.ref || '—'}</td>
      <td>
        <button class="btn-icon btn-edit" onclick="editTreso('${t.id}')"><i class="fas fa-edit"></i></button>
        <button class="btn-icon btn-delete" onclick="deleteItem('treso','${t.id}',renderTreso)"><i class="fas fa-trash"></i></button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Aucun mouvement</td></tr>';
}

function editTreso(id) {
  const t = DB.load('treso').find(x => x.id === id);
  if (!t) return;
  openModal('modalTreso', false);
  document.getElementById('tresoId').value = t.id;
  document.getElementById('tresoDate').value = t.date;
  document.getElementById('tresoLibelle').value = t.libelle;
  document.getElementById('tresoType').value = t.type;
  document.getElementById('tresoMontant').value = t.montant;
  document.getElementById('tresoCompte').value = t.compte;
  document.getElementById('tresoRef').value = t.ref;
}

function updateTresoKPIs() {
  const list = DB.load('treso');
  const entrees = list.filter(t => t.type === 'entrée').reduce((s, t) => s + t.montant, 0);
  const sorties = list.filter(t => t.type === 'sortie').reduce((s, t) => s + t.montant, 0);
  const solde = entrees - sorties;
  document.getElementById('tresoEntrees').textContent = fmt(entrees);
  document.getElementById('tresoSorties').textContent = fmt(sorties);
  document.getElementById('tresoSolde').textContent = fmt(solde);
  const card = document.getElementById('soldeTresoCard');
  if (solde < 0) { card.classList.remove('kpi-blue'); card.classList.add('kpi-red'); }
  else { card.classList.remove('kpi-red'); card.classList.add('kpi-blue'); }
}

// ══════════════════════════════════════════
// UTILISATEURS (ADMIN)
// ══════════════════════════════════════════
function saveUser() {
  const id = document.getElementById('userId').value;
  const data = {
    id: id || uid(),
    nom: document.getElementById('userNom').value.trim(),
    login: document.getElementById('userLogin').value.trim(),
    mdp: document.getElementById('userMdp').value,
    role: document.getElementById('userRole').value,
    ville: document.getElementById('userVille').value.trim(),
    statut: document.getElementById('userStatut').value
  };
  if (!data.nom || !data.login || !data.mdp) { toast('Nom, login et mot de passe obligatoires', 'error'); return; }
  let list = DB.load('users');
  if (!id && list.find(u => u.login === data.login)) { toast('Ce login est déjà utilisé', 'error'); return; }
  if (id) list = list.map(u => u.id === id ? { ...u, ...data } : u);
  else list.push(data);
  DB.save('users', list);
  closeModal('modalUser');
  renderUsers();
  toast('Utilisateur enregistré');
}

function renderUsers() {
  const list = DB.load('users');
  const tbody = document.getElementById('bodyUsers');
  tbody.innerHTML = list.length ? list.map((u, i) => `
    <tr>
      <td>${i + 1}</td>
      <td><strong>${u.nom}</strong></td>
      <td><code>${u.login}</code></td>
      <td>${statusBadge(u.role)}</td>
      <td>${u.ville || '—'}</td>
      <td>${statusBadge(u.statut)}</td>
      <td>
        ${u.login !== 'admin' ? `<button class="btn-icon btn-delete" onclick="deleteUser('${u.id}')"><i class="fas fa-trash"></i></button>` : '<span style="color:var(--text-muted);font-size:.75rem">Protégé</span>'}
      </td>
    </tr>`).join('') : '';
}

function deleteUser(id) {
  if (!confirm('Supprimer cet utilisateur ?')) return;
  let list = DB.load('users').filter(u => u.id !== id);
  DB.save('users', list);
  renderUsers();
  toast('Utilisateur supprimé', 'error');
}

// ══════════════════════════════════════════
// CONFIGURATION
// ══════════════════════════════════════════
function saveConfig() {
  CONFIG = {
    nom: document.getElementById('confNom').value,
    devise: document.getElementById('confDevise').value,
    adresse: document.getElementById('confAdresse').value,
    tel: document.getElementById('confTel').value,
    email: document.getElementById('confEmail').value,
    tva: parseFloat(document.getElementById('confTva').value) || 16
  };
  DB.saveObj('config', CONFIG);
  toast('Configuration enregistrée');
}

// ══════════════════════════════════════════
// SUPPRESSION GÉNÉRIQUE
// ══════════════════════════════════════════
function deleteItem(key, id, renderFn) {
  if (!confirm('Supprimer cet élément ?')) return;
  let list = DB.load(key).filter(x => x.id !== id);
  DB.save(key, list);
  renderFn();
  updateKPIs();
  toast('Élément supprimé', 'error');
}

// ══════════════════════════════════════════
// FERMER MODAL AU CLIC FOND
// ══════════════════════════════════════════
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// ENTER pour connexion
document.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && document.getElementById('loginPage').classList.contains('active')) {
    doLogin();
  }
});

// ══════════════════════════════════════════
// INIT
// ══════════════════════════════════════════
initUsers();
